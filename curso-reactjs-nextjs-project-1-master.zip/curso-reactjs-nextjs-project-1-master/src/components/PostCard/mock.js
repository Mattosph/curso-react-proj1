export const postCardPropsMock = {
  title: 'title 1',
  body: 'body 1',
  id: 1,
  cover: 'img/img.png',
};
